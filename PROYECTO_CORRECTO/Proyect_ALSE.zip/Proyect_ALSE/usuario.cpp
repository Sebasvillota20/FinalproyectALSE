#include "usuario.h"

usuario::usuario()
{

}

usuario::~usuario(){

}
