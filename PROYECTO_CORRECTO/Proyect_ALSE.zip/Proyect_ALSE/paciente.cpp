#include "paciente.h"

paciente::paciente(){

}

paciente::~paciente(){

}
